
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class Aparcamiento {

    // ---------------- CONFIGURACIÓN ----------------

    static final int NUM_COCHES = 20;
    static final int NUM_SURTIDORES = 2;
    static final int PLAZAS_PARKING = 10;

    static int gasolinaDisponible = 80;

    static final int RECARGA_REPONEDOR = 200;

    // ---------------- DEPÓSITO ----------------

    // Crear una cola que represente los litros de gasolina disponibles
    static Queue<Integer> gasolina = new LinkedList<>();


    // Inicializar la cola con la gasolina inicial
    static {
        for (int i = 0; i < gasolinaDisponible; i++) {
            gasolina.add(1);
        }
    }

    // ---------------- DATOS DE LOS COCHES ----------------

    static int[] gasolinaCoches = {
            0, 15, 20, 0, 10,
            25, 30, 5, 0, 12,
            18, 22, 0, 8, 16,
            14, 0, 27, 9, 19
    };

    static int[] tiempoParking = {
            800, 1500, 1200, 600, 2000,
            900, 1700, 1100, 700, 1400,
            1000, 1600, 500, 1300, 1800,
            950, 650, 1750, 1050, 1550
    };


    // ---------------- SEMÁFOROS ----------------


    // semáforo para surtidores
    static Semaphore surtidores = new Semaphore(NUM_SURTIDORES);

    // semáforo para gasolina disponible en el depósito
    static Semaphore gasolinaDisponibleSem = new Semaphore(gasolinaDisponible);

    // semáforo para plazas del parking
    static Semaphore plazasParking = new Semaphore(PLAZAS_PARKING);

    // semáforo para el cruce
    static Semaphore cruce = new Semaphore(1);

    // semáforo de exclusión mutua para el depósito
    static Semaphore mutexGasolina = new Semaphore(1);



    // ---------------- COCHE ----------------

    static class Coche implements Runnable {

        int id;
        int gasolinaNecesaria;
        int tiempoAparcado;

        public Coche(int id, int gasolinaNecesaria, int tiempoAparcado) {
            this.id = id;
            this.gasolinaNecesaria = gasolinaNecesaria;
            this.tiempoAparcado = tiempoAparcado;
        }

        @Override
        public void run() {

            try {

                // -------- GASOLINERA --------

                if (gasolinaNecesaria > 0) {

                    // 1. Esperar turno y consumir gasolina
                    surtidores.acquire();

                    System.out.println("Coche " + id + " entra en la gasolinera");

                    for (int i = 0; i < gasolinaNecesaria; i++) {

                        gasolinaDisponibleSem.acquire();

                        mutexGasolina.acquire();
                        gasolina.poll();
                        mutexGasolina.release();
                    }

                    // 2. Cada coche tarda 1 segundo en salir del surtidor
                    Thread.sleep(1000);

                    System.out.println("Coche " + id + " sale de la gasolinera");

                    surtidores.release();
                }


                // -------- CRUCE --------

                // Los coches deben cruzar el cruce de uno en uno
                cruce.acquire();

                System.out.println("Coche " + id + " entra en el cruce");

                Thread.sleep(200);

                System.out.println("Coche " + id + " sale del cruce");

                cruce.release();


                // -------- PARKING --------

                plazasParking.acquire();

                System.out.println("Coche " + id + " entra al parking");

                Thread.sleep(tiempoAparcado);

                System.out.println("Coche " + id + " sale del parking");

                plazasParking.release();


            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // ---------------- REPONEDOR ----------------

    static class Reponedor implements Runnable {

        @Override
        public void run() {

            try {

                // Esperar el tiempo indicado
                Thread.sleep(3000);

                mutexGasolina.acquire();

                // Añadir gasolina al depósito
                for (int i = 0; i < RECARGA_REPONEDOR; i++) {
                    gasolina.add(1);
                    gasolinaDisponibleSem.release();
                }

                mutexGasolina.release();

                System.out.println("Camión cisterna ha repuesto gasolina");

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // ---------------- MAIN ----------------

    public void ejecutar() {

        // 1. Crear e iniciar el hilo reponedor
        Thread reponedor = new Thread(new Reponedor());
        reponedor.start();

        for (int i = 0; i < NUM_COCHES; i++) {

            // 2. Crear los hilos de los coches usando los arrays gasolinaCoches y tiempoParking
            Thread coche = new Thread(
                    new Coche(i, gasolinaCoches[i], tiempoParking[i])
            );

            coche.start();


        }
    }
}