
public class Main {
    public static void main(String[] args) {

        Aparcamiento ap = new Aparcamiento();
        ap.ejecutar();
        //Parking p = new Parking();
        //p.execute();

    }
}
